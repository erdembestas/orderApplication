var obj;
var obj2;
var drinkOrdered = "";
var foodOrdered = "";
var orderPrinted = "";
var orderInfo = document.querySelector(".orderInfo");
var command = "";
var x = document.querySelector("#fFood");
var y = document.querySelector("#fDrink");
function myFunction() {
  console.log("Okey!");
}
function addToOrder() {
  drinkOrdered = "";
  foodOrdered = "";
  orderPrinted = "";
  var totalPrice = 0;
  var len = obj.length;
  for (i = 0; i <= len - 1; i++) {
    var id = "#" + "drink" + (i + 1);
    var checker = document.querySelector(id);

    if (checker.checked == true) {
      drinkOrdered = drinkOrdered + checker.value + ";";
      totalPrice = totalPrice + obj[i].price;
      orderPrinted =
        orderPrinted +
        "<div class='doFlex'>" +
        "<div>" +
        checker.name +
        "</div>" +
        "<div>" +
        obj[i].price +
        " $" +
        "</div>" +
        "</div>";
    }
  }
  if (orderPrinted != "") {
    orderPrinted =
      "<br>" +
      "<div>Drinks:</div>" +
      "<br>" +
      orderPrinted +
      "<br>" +
      "<div>Foods:</div>" +
      "<br>";
  }

  var len2 = obj2.length;
  for (i = 0; i <= len2 - 1; i++) {
    var id2 = "#" + "food" + (i + 1);
    var checker2 = document.querySelector(id2);

    if (checker2.checked == true) {
      foodOrdered = foodOrdered + checker2.value + ";";
      totalPrice = totalPrice + obj2[i].price;
      orderPrinted =
        orderPrinted +
        "<div class='doFlex'>" +
        "<div>" +
        checker2.name +
        "</div>" +
        "<div>" +
        obj2[i].price +
        " $" +
        "</div>" +
        "</div>";
    }
  }
  if (orderPrinted != "") {
    orderPrinted =
      orderPrinted +
      "<div class='line'>" +
      "</div>" +
      "<div class='toRight'>" +
      "Total Price : " +
      totalPrice +
      "</div>";
  }
  orderInfo.innerHTML = orderPrinted;

  foodOrdered = foodOrdered.slice(0, -1);
  drinkOrdered = drinkOrdered.slice(0, -1);
  console.log("drink:" + drinkOrdered);
  console.log("food:" + foodOrdered);
  console.log("Added!");

  x.value = foodOrdered;
  y.value = drinkOrdered;
}
function createTheHtml_Drink(data, length_data) {
  for (i = 0; i <= length_data - 1; i++) {
    var idDrink = "drink" + (i + 1);
    var inputCreated = document.createElement("input");
    inputCreated.setAttribute("type", "checkbox");
    inputCreated.setAttribute("id", idDrink);
    inputCreated.setAttribute("name", data[i].name);
    inputCreated.setAttribute("value", data[i].id);
    inputCreated.setAttribute("onclick", "myFunction()");
    var labelCr = document.createElement("label");
    labelCr.setAttribute("for", idDrink);
    labelCr.innerHTML = data[i].name + " :   " + data[i].price + "  $";
    var element = document.querySelector(".drinkForm");
    var outerDiv = document.createElement("div");
    outerDiv.setAttribute("class", "inputDiv");

    outerDiv.appendChild(labelCr);
    outerDiv.appendChild(inputCreated);
    var details = document.createElement("p");
    details.setAttribute("class", "drinkDetail");
    details.innerHTML =
      "<strong>Ingredients : </strong>" +
      data[i].ingredients +
      "<br>" +
      "<strong>Food Type : </strong>" +
      data[i].type +
      "<br>" +
      "<strong>Food Description : </strong>" +
      data[i].description +
      "<br>";

    element.appendChild(outerDiv);
    element.appendChild(details);
    /* 
    var newProduct = document.createElement("p");

    var name = data[i].name;
    var node = document.createTextNode(name);
    newProduct.appendChild(node);
    const element = document.querySelector(".drinkSide");
    element.appendChild(newProduct);
    newProduct.classList.add("solid"); */
  }
}
function createTheHtml_Food(data, length_data) {
  for (i = 0; i <= length_data - 1; i++) {
    var idFood = "food" + (i + 1);
    var inputCreated = document.createElement("input");
    inputCreated.setAttribute("type", "checkbox");
    inputCreated.setAttribute("id", idFood);
    inputCreated.setAttribute("name", data[i].name);
    inputCreated.setAttribute("value", data[i].id);
    inputCreated.setAttribute("onclick", "myFunction()");
    var labelCr = document.createElement("label");
    labelCr.setAttribute("for", idFood);
    labelCr.innerHTML = data[i].name + " :   " + data[i].price + "  $";
    var element = document.querySelector(".foodForm");
    var outerDiv = document.createElement("div");
    outerDiv.setAttribute("class", "inputDiv");

    outerDiv.appendChild(labelCr);
    outerDiv.appendChild(inputCreated);
    var details = document.createElement("p");
    details.setAttribute("class", "foodDetail");
    details.innerHTML =
      "<strong>Ingredients : </strong>" +
      data[i].ingredients +
      "<br>" +
      "<strong>Drink Type : </strong>" +
      data[i].type;

    element.appendChild(outerDiv);
    element.appendChild(details);
  }
}

/* let response = await fetch(opts);
   let obj = await response.json(); */
fetch("http://localhost:3000/drinks/rows/")
  .then((response) => response.text())
  .then((text) => {
    console.log(text);
    obj = JSON.parse(text);
    var size = obj.length;
    createTheHtml_Drink(obj, size);
  })
  .catch((err) => {
    console.log(err);
  });

fetch("http://localhost:3000/foods/rows/")
  .then((response) => response.text())
  .then((text) => {
    console.log(text);
    obj2 = JSON.parse(text);
    var size2 = obj2.length;
    createTheHtml_Food(obj2, size2);
  })
  .catch((err) => {
    console.log(err);
  });

/* $("#sendForm").click(function (e) {
  e.preventDefault();
  var data = {};
  data.fname = $("#fname").val();
  data.fsurname = $("#fsurname").val();
  data.fmail = $("#fmail").val();
  data.fcity = $("#fcity").val();
  data.msg = $("#msg").val();
  data.ffood = $("#ffood").val();
  data.fdrink = $("#fdrink").val();

  $.ajax({
    url: "/order",
    type: "POST",
    //                contentType: 'application/json',
    //                dataType: "json",
    data: JSON.stringify(data),
    success: function (data) {
      alert("success");
      console.log("succes returned in ajax");
    },
    error: function (a, b, c) {
      alert("Failed Order");
      console.log("post resulted in failure");
    },
  });
});
 */
