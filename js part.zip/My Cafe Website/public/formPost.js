$(() => {
  const $form = $("#userForm");

  $form.on("submit", handleSend);

  function handleSend(e) {
    e.preventDefault();

    var fname = $("#fname").val();
    var fsurname = $("#fsurname").val();
    var fmail = $("#fmail").val();
    var fcity = $("#fcity").val();
    var msg = $("#msg").val();
    var ffood = $("#ffood").val();
    var fdrink = $("#fdrink").val();

    var pa = !(fname === "");
    var pb = !(fsurname === "");
    var pc = !(fmail === "");
    var pd = !(fcity === "");
    var pe = !(msg === "");
    var pf = !(fdrink === "" && ffood === "");

    if (pa && pb && pc && pd && pe && pf) {
      const options = {
        method: $form.attr("method"),
        url: $form.attr("action"),
        data: $form.serialize(),
      };

      $.ajax(options).done((response) => {
        console.log(response);
        alert("Succesfully Sent!");
      });
      window.location = window.location;
    } else {
      alert("Please Fill Empty Areas and Make Your Choices");
    }
  }
});
