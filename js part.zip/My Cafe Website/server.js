var express = require("express");
var app = express();
var mysql = require("mysql2");
var bodyParser = require("body-parser");

/* var drinkSide = document.getElementsByClassName("drinkSide"); */
app.use(express.static("public"));
var connection = mysql.createConnection({
  host: "localhost",
  user: "root",
  password: "Sertan1602-A0216-",
  database: "restaurant",
});

connection.connect();
app.get("/drinks/rows", function (req, res) {
  connection.query("SELECT * FROM drinks", function (err, rows, fields) {
    if (err) throw err;
    res.send(JSON.stringify(rows));
  });
});
app.get("/foods/rows", function (req, res) {
  connection.query("SELECT * FROM foods", function (err, rows, fields) {
    if (err) throw err;
    res.send(JSON.stringify(rows));
  });
});
app.use(bodyParser.urlencoded({ extended: true }));

app.post("/order", (req, res) => {
  var fname = req.body.fname;
  var fsurname = req.body.fsurname;
  var fmail = req.body.fmail;
  var faddress = req.body.msg;
  var fcity = req.body.fcity;
  var fdrink = req.body.fdrink;
  var ffood = req.body.ffood;

  var sqlSent1 =
    "INSERT INTO orders (foods, drinks, customerName, customerSurname, customerMail, customerCity, customerAddress) ";
  var sqlSent2 =
    "VALUES (" +
    `"${ffood}","${fdrink}","${fname}","${fsurname}","${fmail}","${fcity}","${faddress}"` +
    ")";
  var sqlSent = sqlSent1 + sqlSent2;
  connection.query(sqlSent, function (err, rows, fields) {
    if (err) throw err;
    console.log("Succesful!!");
  });

  res.send("Done");
  /* res.send(`Full name is:${req.body.fdrink} ${req.body.ffood}.`); */
});

/* app.get("/order", function (req, res) {
  // This will run every time you send a request to localhost:3000/search
  var term = req.params.command;
  var sqlSent = `INSERT INTO orders (foods, drinks, customerName, customerSurname, customerMail, customerCity, customerAddress) VALUES (${term})`;

  connection.query(sqlSent, function (err) {
    if (err) throw err;

    res.send("Hello");
  });
}); */
/* connection.end(); */
app.listen(3000, function () {
  console.log("Example app listening on port 3000!");
});
/*http://localhost:3000/index.html*/
